<?php

use App\Http\Controllers\Api\AdminController;
use App\Http\Controllers\Api\AppointmentController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\FavoriteController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\Api\ReviewController;
use App\Http\Controllers\Api\SalonController;
use App\Http\Controllers\Api\ScheduleController;
use App\Http\Controllers\Api\ServiceController;
use App\Http\Controllers\Api\StaffController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/
Route::middleware('guest')->group(function () {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);
});

// Ostale rute (npr. zaštićene) ostaju unutar auth:sanctum grupe
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/user', [AuthController::class, 'user']);
    // Ostale zaštićene rute...
});



// Salon public routes
Route::get('/salons', [SalonController::class, 'index']);
Route::get('/salons/{salon}', [SalonController::class, 'show']);
Route::get('/salons/{salon}/services', [ServiceController::class, 'index']);
Route::get('/salons/{salon}/services/by-category', [ServiceController::class, 'byCategory']);
Route::get('/salons/{salon}/staff', [StaffController::class, 'index']);
Route::get('/salons/{salon}/reviews', [ReviewController::class, 'index']);
Route::get('/salons/nearest', [SalonController::class, 'nearest']);

// Protected routes
Route::middleware('auth:sanctum')->group(function () {
    // Auth routes
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/user', [AuthController::class, 'user']);
    Route::put('/user/profile', [AuthController::class, 'updateProfile']);
    Route::put('/user/password', [AuthController::class, 'changePassword']);
    Route::post('/user/avatar', [AuthController::class, 'uploadAvatar']);
    Route::get('/user/notifications', [NotificationController::class, 'userNotifications']);
    Route::put('/user/notifications/{notification}/read', [NotificationController::class, 'markAsRead']);
    Route::put('/user/notifications/read-all', [NotificationController::class, 'markAllAsRead']);
    Route::get('/user/notifications/unread-count', [NotificationController::class, 'unreadCount']);
    Route::delete('/user/notifications/{notification}', [NotificationController::class, 'destroy']);
    Route::get('/user/favorites', [FavoriteController::class, 'index']);
    Route::post('/user/favorites/{salon}', [FavoriteController::class, 'store']);
    Route::delete('/user/favorites/{salon}', [FavoriteController::class, 'destroy']);
    Route::get('/user/favorites/{salon}/check', [FavoriteController::class, 'check']);
    Route::get('/user/appointments', [AppointmentController::class, 'index']);
    Route::post('/user/appointments', [AppointmentController::class, 'store']);
    Route::get('/user/appointments/{appointment}', [AppointmentController::class, 'show']);
    Route::put('/user/appointments/{appointment}', [AppointmentController::class, 'update']);
    Route::delete('/user/appointments/{appointment}', [AppointmentController::class, 'destroy']);
    Route::put('/user/appointments/{appointment}/cancel', [AppointmentController::class, 'cancel']);

      Route::put('/user/profile', [AuthController::class, 'updateProfile']);
    Route::put('/salon/profile', [SalonController::class, 'updateProfile']);






    // Salon routes
    Route::post('/salons', [SalonController::class, 'store']);
    Route::put('/salons/{salon}', [SalonController::class, 'update']);
    Route::delete('/salons/{salon}', [SalonController::class, 'destroy']);
    Route::post('/salons/{salon}/images', [SalonController::class, 'uploadImages']);
    Route::delete('/salons/{salon}/images/{image}', [SalonController::class, 'deleteImage']);
    Route::put('/salons/{salon}/images/{image}/primary', [SalonController::class, 'setPrimaryImage']);
    Route::get('/salons/{salon}/available-slots', [SalonController::class, 'availableSlots']);

    // Staff routes
    Route::post('/salons/{salon}/staff', [StaffController::class, 'store']);
    Route::get('/salons/{salon}/staff/{staff}', [StaffController::class, 'show']);
    Route::put('/salons/{salon}/staff/{staff}', [StaffController::class, 'update']);
    Route::delete('/salons/{salon}/staff/{staff}', [StaffController::class, 'destroy']);
    Route::post('/salons/{salon}/staff/{staff}/avatar', [StaffController::class, 'uploadAvatar']);
    Route::get('/salons/{salon}/staff/{staff}/schedule', [StaffController::class, 'schedule']);
    Route::get('/salons/{salon}/staff/{staff}/appointments', [StaffController::class, 'appointments']);

    // Service routes
    Route::post('/salons/{salon}/services', [ServiceController::class, 'store']);
    Route::get('/salons/{salon}/services/{service}', [ServiceController::class, 'show']);
    Route::put('/salons/{salon}/services/{service}', [ServiceController::class, 'update']);
    Route::delete('/salons/{salon}/services/{service}', [ServiceController::class, 'destroy']);

    // Appointment routes
    Route::middleware('auth:sanctum')->group(function () {
    Route::get('/appointments', [AppointmentController::class, 'index']);
    Route::post('/appointments', [AppointmentController::class, 'store']);
    Route::get('/appointments/{appointment}', [AppointmentController::class, 'show']);
    Route::put('/appointments/{appointment}', [AppointmentController::class, 'update']);
    Route::delete('/appointments/{appointment}', [AppointmentController::class, 'destroy']);
    Route::put('/appointments/{appointment}/cancel', [AppointmentController::class, 'cancel']);
});


    // Review routes
    Route::post('/reviews', [ReviewController::class, 'store']);
    Route::get('/reviews/{review}', [ReviewController::class, 'show']);
    Route::put('/reviews/{review}', [ReviewController::class, 'update']);
    Route::delete('/reviews/{review}', [ReviewController::class, 'destroy']);
    Route::post('/reviews/{review}/response', [ReviewController::class, 'addResponse']);

    // Schedule routes
    Route::get('/salons/{salon}/breaks', [ScheduleController::class, 'getSalonBreaks']);
    Route::post('/salons/{salon}/breaks', [ScheduleController::class, 'storeSalonBreak']);
    Route::put('/salons/{salon}/breaks/{break}', [ScheduleController::class, 'updateSalonBreak']);
    Route::delete('/salons/{salon}/breaks/{break}', [ScheduleController::class, 'deleteSalonBreak']);

    Route::get('/salons/{salon}/vacations', [ScheduleController::class, 'getSalonVacations']);
    Route::post('/salons/{salon}/vacations', [ScheduleController::class, 'storeSalonVacation']);
    Route::put('/salons/{salon}/vacations/{vacation}', [ScheduleController::class, 'updateSalonVacation']);
    Route::delete('/salons/{salon}/vacations/{vacation}', [ScheduleController::class, 'deleteSalonVacation']);

    Route::get('/staff/{staff}/breaks', [ScheduleController::class, 'getStaffBreaks']);
    Route::post('/staff/{staff}/breaks', [ScheduleController::class, 'storeStaffBreak']);
    Route::put('/staff/{staff}/breaks/{break}', [ScheduleController::class, 'updateStaffBreak']);
    Route::delete('/staff/{staff}/breaks/{break}', [ScheduleController::class, 'deleteStaffBreak']);

    Route::get('/staff/{staff}/vacations', [ScheduleController::class, 'getStaffVacations']);
    Route::post('/staff/{staff}/vacations', [ScheduleController::class, 'storeStaffVacation']);
    Route::put('/staff/{staff}/vacations/{vacation}', [ScheduleController::class, 'updateStaffVacation']);
    Route::delete('/staff/{staff}/vacations/{vacation}', [ScheduleController::class, 'deleteStaffVacation']);

    // Favorite routes
    Route::get('/favorites', [FavoriteController::class, 'index']);
    Route::post('/favorites/{salon}', [FavoriteController::class, 'store']);
    Route::delete('/favorites/{salon}', [FavoriteController::class, 'destroy']);
    Route::get('/favorites/{salon}/check', [FavoriteController::class, 'check']);

    // Notification routes
    Route::get('/notifications', [NotificationController::class, 'index']);
    Route::put('/notifications/{notification}/read', [NotificationController::class, 'markAsRead']);
    Route::put('/notifications/read-all', [NotificationController::class, 'markAllAsRead']);
    Route::get('/notifications/unread-count', [NotificationController::class, 'unreadCount']);
    Route::delete('/notifications/{notification}', [NotificationController::class, 'destroy']);

    // Admin routes
    Route::middleware('admin')->prefix('admin')->group(function () {
        Route::get('/dashboard', [AdminController::class, 'dashboardStats']);
        Route::get('/users', [AdminController::class, 'users']);
        Route::get('/salons', [AdminController::class, 'salons']);
        Route::put('/salons/{salon}/approve', [AdminController::class, 'approveSalon']);
        Route::put('/salons/{salon}/suspend', [AdminController::class, 'suspendSalon']);
        Route::get('/analytics', [AdminController::class, 'analytics']);
    });

});
