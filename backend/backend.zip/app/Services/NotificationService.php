<?php

namespace App\Services;

use App\Models\Appointment;
use App\Models\Notification;
use App\Models\Review;
use App\Models\Salon;
use App\Models\User;

class NotificationService
{
    /**
     * Send notifications for a new appointment.
     */
    public function sendNewAppointmentNotifications(Appointment $appointment): void
    {
        // Notify salon owner
        $salon = $appointment->salon;
        $owner = $salon->owner;
        
        Notification::create([
            'type' => 'new_appointment',
            'title' => 'Novi termin',
            'message' => "Novi termin zakazan za {$appointment->date} u {$appointment->time}",
            'recipient_id' => $owner->id,
            'related_id' => $appointment->id,
        ]);

        // Notify staff member
        $staff = $appointment->staff;
        if ($staff->user_id) {
            Notification::create([
                'type' => 'new_appointment',
                'title' => 'Novi termin',
                'message' => "Novi termin zakazan za {$appointment->date} u {$appointment->time}",
                'recipient_id' => $staff->user_id,
                'related_id' => $appointment->id,
            ]);
        }

        // Notify client
        Notification::create([
            'type' => 'appointment_confirmed',
            'title' => 'Termin zakazan',
            'message' => "Vaš termin je zakazan za {$appointment->date} u {$appointment->time} u salonu {$salon->name}",
            'recipient_id' => $appointment->client_id,
            'related_id' => $appointment->id,
        ]);
    }

    /**
     * Send notifications for appointment status change.
     */
    public function sendAppointmentStatusChangeNotifications(Appointment $appointment, string $oldStatus): void
    {
        $salon = $appointment->salon;
        
        // Notify client
        switch ($appointment->status) {
            case 'confirmed':
                Notification::create([
                    'type' => 'appointment_confirmed',
                    'title' => 'Termin potvrđen',
                    'message' => "Vaš termin za {$appointment->date} u {$appointment->time} u salonu {$salon->name} je potvrđen",
                    'recipient_id' => $appointment->client_id,
                    'related_id' => $appointment->id,
                ]);
                break;
                
            case 'cancelled':
                Notification::create([
                    'type' => 'appointment_cancelled',
                    'title' => 'Termin otkazan',
                    'message' => "Vaš termin za {$appointment->date} u {$appointment->time} u salonu {$salon->name} je otkazan",
                    'recipient_id' => $appointment->client_id,
                    'related_id' => $appointment->id,
                ]);
                break;
                
            case 'completed':
                Notification::create([
                    'type' => 'appointment_completed',
                    'title' => 'Termin završen',
                    'message' => "Vaš termin u salonu {$salon->name} je uspješno završen. Možete ostaviti recenziju.",
                    'recipient_id' => $appointment->client_id,
                    'related_id' => $appointment->id,
                ]);
                break;
        }

        // Notify salon owner if client cancelled
        if ($appointment->status === 'cancelled' && $oldStatus !== 'cancelled') {
            $owner = $salon->owner;
            
            Notification::create([
                'type' => 'appointment_cancelled',
                'title' => 'Termin otkazan',
                'message' => "Termin za {$appointment->date} u {$appointment->time} je otkazan od strane klijenta",
                'recipient_id' => $owner->id,
                'related_id' => $appointment->id,
            ]);
        }

        // Notify staff member
        $staff = $appointment->staff;
        if ($staff->user_id) {
            switch ($appointment->status) {
                case 'confirmed':
                    Notification::create([
                        'type' => 'appointment_confirmed',
                        'title' => 'Termin potvrđen',
                        'message' => "Termin za {$appointment->date} u {$appointment->time} je potvrđen",
                        'recipient_id' => $staff->user_id,
                        'related_id' => $appointment->id,
                    ]);
                    break;
                    
                case 'cancelled':
                    Notification::create([
                        'type' => 'appointment_cancelled',
                        'title' => 'Termin otkazan',
                        'message' => "Termin za {$appointment->date} u {$appointment->time} je otkazan",
                        'recipient_id' => $staff->user_id,
                        'related_id' => $appointment->id,
                    ]);
                    break;
            }
        }
    }

    /**
     * Send notifications for a new review.
     */
    public function sendNewReviewNotifications(Review $review): void
    {
        // Notify salon owner
        $salon = $review->salon;
        $owner = $salon->owner;
        
        Notification::create([
            'type' => 'new_review',
            'title' => 'Nova recenzija',
            'message' => "Nova recenzija sa ocjenom {$review->rating}/5 za vaš salon",
            'recipient_id' => $owner->id,
            'related_id' => $review->id,
        ]);

        // Notify staff member
        if ($review->staff_id) {
            $staff = $review->staff;
            if ($staff->user_id) {
                Notification::create([
                    'type' => 'new_review',
                    'title' => 'Nova recenzija',
                    'message' => "Nova recenzija sa ocjenom {$review->rating}/5 za vas",
                    'recipient_id' => $staff->user_id,
                    'related_id' => $review->id,
                ]);
            }
        }
    }

    /**
     * Send notification for a review response.
     */
    public function sendReviewResponseNotification(Review $review): void
    {
        Notification::create([
            'type' => 'review_response',
            'title' => 'Odgovor na recenziju',
            'message' => "Salon {$review->salon->name} je odgovorio na vašu recenziju",
            'recipient_id' => $review->client_id,
            'related_id' => $review->id,
        ]);
    }

    /**
     * Send notification for adding a salon to favorites.
     */
    public function sendFavoriteAddedNotification(User $user, Salon $salon): void
    {
        Notification::create([
            'type' => 'favorite_added',
            'title' => 'Salon dodan u omiljene',
            'message' => "Salon {$salon->name} je dodan u vaše omiljene",
            'recipient_id' => $user->id,
            'related_id' => $salon->id,
        ]);
    }

    /**
     * Send notification for removing a salon from favorites.
     */
    public function sendFavoriteRemovedNotification(User $user, Salon $salon): void
    {
        Notification::create([
            'type' => 'favorite_removed',
            'title' => 'Salon uklonjen iz omiljenih',
            'message' => "Salon {$salon->name} je uklonjen iz vaših omiljenih",
            'recipient_id' => $user->id,
            'related_id' => $salon->id,
        ]);
    }

    /**
     * Send notification for salon status change.
     */
    public function sendSalonStatusChangeNotification(Salon $salon, string $status): void
    {
        $statusText = $status === 'approved' ? 'odobren' : 'suspendovan';
        
        Notification::create([
            'type' => 'salon_status_change',
            'title' => 'Status salona promijenjen',
            'message' => "Vaš salon {$salon->name} je {$statusText}",
            'recipient_id' => $salon->owner_id,
            'related_id' => $salon->id,
        ]);
    }
}