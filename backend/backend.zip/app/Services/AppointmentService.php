<?php

namespace App\Services;

use App\Models\Appointment;
use App\Models\Staff;

class AppointmentService
{
    /**
     * Calculate the end time for an appointment.
     */
    public function calculateEndTime(string $startTime, int $duration): string
    {
        $startTimestamp = strtotime($startTime);
        $endTimestamp = $startTimestamp + ($duration * 60);
        
        return date('H:i', $endTimestamp);
    }

    /**
     * Check if a staff member is available at a specific date and time.
     */
    public function isStaffAvailable(Staff $staff, string $date, string $time, int $duration, ?string $excludeAppointmentId = null): bool
    {
        // Convert date to day of week
        $dayOfWeek = strtolower(date('l', strtotime($date)));
        
        // Check working hours
        $workingHours = $staff->working_hours[$dayOfWeek] ?? null;
        if (!$workingHours || !$workingHours['is_working']) {
            return false;
        }
        
        // Check if time is within working hours
        $startTime = strtotime($workingHours['start']);
        $endTime = strtotime($workingHours['end']);
        $appointmentTime = strtotime($time);
        $appointmentEndTime = strtotime("+{$duration} minutes", $appointmentTime);
        
        if ($appointmentTime < $startTime || $appointmentEndTime > $endTime) {
            return false;
        }
        
        // Check for salon breaks
        $salon = $staff->salon;
        foreach ($salon->salonBreaks as $break) {
            if (!$break->is_active) continue;
            
            if ($break->appliesTo($date)) {
                $breakStart = strtotime($break->start_time);
                $breakEnd = strtotime($break->end_time);
                
                // Check if appointment overlaps with break
                if (($appointmentTime < $breakEnd) && ($appointmentEndTime > $breakStart)) {
                    return false;
                }
            }
        }
        
        // Check for salon vacations
        foreach ($salon->salonVacations as $vacation) {
            if (!$vacation->is_active) continue;
            
            if ($vacation->isActiveFor($date)) {
                return false;
            }
        }
        
        // Check for staff breaks
        foreach ($staff->breaks as $break) {
            if (!$break->is_active) continue;
            
            if ($break->appliesTo($date)) {
                $breakStart = strtotime($break->start_time);
                $breakEnd = strtotime($break->end_time);
                
                // Check if appointment overlaps with break
                if (($appointmentTime < $breakEnd) && ($appointmentEndTime > $breakStart)) {
                    return false;
                }
            }
        }
        
        // Check for staff vacations
        foreach ($staff->vacations as $vacation) {
            if (!$vacation->is_active) continue;
            
            if ($vacation->isActiveFor($date)) {
                return false;
            }
        }
        
        // Check for existing appointments
        $query = Appointment::where('staff_id', $staff->id)
            ->where('date', $date)
            ->whereIn('status', ['confirmed', 'in_progress']);
            
        // Exclude the current appointment if updating
        if ($excludeAppointmentId) {
            $query->where('id', '!=', $excludeAppointmentId);
        }
        
        $existingAppointments = $query->get();
        
        foreach ($existingAppointments as $appointment) {
            $existingStart = strtotime($appointment->time);
            $existingEnd = strtotime($appointment->end_time);
            
            // Check if appointment overlaps with existing appointment
            if (($appointmentTime < $existingEnd) && ($appointmentEndTime > $existingStart)) {
                return false;
            }
        }
        
        return true;
    }

    /**
     * Get available dates for a staff member and service.
     */
    public function getAvailableDates(Staff $staff, int $serviceId, int $daysAhead = 30): array
    {
        $service = $staff->services()->findOrFail($serviceId);
        $availableDates = [];
        $today = now();
        
        for ($i = 0; $i < $daysAhead; $i++) {
            $date = $today->copy()->addDays($i);
            $dateString = $date->format('d.m.Y');
            
            // Check if there's at least one available slot on this date
            $dayOfWeek = strtolower($date->format('l'));
            
            // Check working hours
            $workingHours = $staff->working_hours[$dayOfWeek] ?? null;
            if (!$workingHours || !$workingHours['is_working']) {
                continue;
            }
            
            // Check for salon vacations
            $salon = $staff->salon;
            $salonVacation = $salon->salonVacations()
                ->where('is_active', true)
                ->where(function ($query) use ($dateString) {
                    $query->whereDate('start_date', '<=', $dateString)
                          ->whereDate('end_date', '>=', $dateString);
                })->exists();
                
            if ($salonVacation) {
                continue;
            }
            
            // Check for staff vacations
            $staffVacation = $staff->vacations()
                ->where('is_active', true)
                ->where(function ($query) use ($dateString) {
                    $query->whereDate('start_date', '<=', $dateString)
                          ->whereDate('end_date', '>=', $dateString);
                })->exists();
                
            if ($staffVacation) {
                continue;
            }
            
            // Generate time slots and check if any are available
            $startTime = $workingHours['start'];
            $endTime = $workingHours['end'];
            $slots = $this->generateTimeSlots($startTime, $endTime);
            
            foreach ($slots as $slot) {
                if ($this->isStaffAvailable($staff, $dateString, $slot, $service->duration)) {
                    $availableDates[] = $dateString;
                    break;
                }
            }
        }
        
        return $availableDates;
    }

    /**
     * Generate time slots between start and end time.
     */
    private function generateTimeSlots(string $startTime, string $endTime, int $interval = 30): array
    {
        $slots = [];
        $start = strtotime($startTime);
        $end = strtotime($endTime);

        for ($time = $start; $time < $end; $time += $interval * 60) {
            $slots[] = date('H:i', $time);
        }

        return $slots;
    }
}