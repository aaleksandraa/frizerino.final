<?php

namespace App\Policies;

use App\Models\Salon;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class SalonPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, Salon $salon): bool
    {
        return true;
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return $user->role === 'salon' || $user->role === 'admin';
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, Salon $salon): bool
    {
        return $user->id === $salon->owner_id || $user->role === 'admin';
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, Salon $salon): bool
    {
        return $user->id === $salon->owner_id || $user->role === 'admin';
    }

    /**
     * Determine whether the user can update staff for the salon.
     */
    public function updateStaff(User $user, Salon $salon): bool
    {
        return $user->id === $salon->owner_id || $user->role === 'admin';
    }

    /**
     * Determine whether the user can update services for the salon.
     */
    public function updateServices(User $user, Salon $salon): bool
    {
        return $user->id === $salon->owner_id || $user->role === 'admin';
    }

    /**
     * Determine whether the user can update schedule for the salon.
     */
    public function updateSchedule(User $user, Salon $salon): bool
    {
        return $user->id === $salon->owner_id || $user->role === 'admin';
    }
}