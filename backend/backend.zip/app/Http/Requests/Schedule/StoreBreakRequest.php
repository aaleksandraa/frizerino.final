<?php

namespace App\Http\Requests\Schedule;

use Illuminate\Foundation\Http\FormRequest;

class StoreBreakRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        if ($this->route('salon')) {
            return $this->user()->id === $this->route('salon')->owner_id || $this->user()->role === 'admin';
        }

        if ($this->route('staff')) {
            $staff = $this->route('staff');
            if ($staff->user_id === $this->user()->id) {
                return true;
            }
            return $this->user()->id === $staff->salon->owner_id || $this->user()->role === 'admin';
        }

        return false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'title' => 'required|string|max:255',
            'type' => 'required|string|in:daily,weekly,specific_date,date_range',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
            'days' => 'required_if:type,weekly|array',
            'days.*' => 'string|in:monday,tuesday,wednesday,thursday,friday,saturday,sunday',
            'date' => 'required_if:type,specific_date|date_format:d.m.Y',
            'start_date' => 'required_if:type,date_range|date_format:d.m.Y',
            'end_date' => 'required_if:type,date_range|date_format:d.m.Y|after_or_equal:start_date',
            'is_active' => 'sometimes|boolean',
        ];
    }
}