<?php

namespace App\Http\Requests\Salon;

use Illuminate\Foundation\Http\FormRequest;

class StoreSalonRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return $this->user()->role === 'salon';
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'address' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'postal_code' => 'nullable|string|max:20',
            'country' => 'nullable|string|max:255',
            'phone' => 'required|string|max:255',
            'email' => 'required|string|email|max:255',
            'website' => 'nullable|string|max:255|url',
            'working_hours' => 'required|json',
            'location' => 'required|json',
            'target_audience' => 'nullable|json',
            'amenities' => 'nullable|array',
            'social_media' => 'nullable|json',
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'name.required' => 'Naziv salona je obavezan',
            'description.required' => 'Opis salona je obavezan',
            'address.required' => 'Adresa salona je obavezna',
            'city.required' => 'Grad je obavezan',
            'phone.required' => 'Telefon je obavezan',
            'email.required' => 'Email je obavezan',
            'email.email' => 'Email mora biti validan',
            'working_hours.required' => 'Radno vrijeme je obavezno',
            'location.required' => 'Lokacija je obavezna',
        ];
    }
}