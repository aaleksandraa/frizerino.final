<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Appointment\StoreAppointmentRequest;
use App\Http\Requests\Appointment\UpdateAppointmentRequest;
use App\Http\Resources\AppointmentResource;
use App\Models\Appointment;
use App\Models\Salon;
use App\Models\Service;
use App\Models\Staff;
use App\Services\AppointmentService;
use App\Services\NotificationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class AppointmentController extends Controller
{
    protected $appointmentService;
    protected $notificationService;

    public function __construct(
        AppointmentService $appointmentService,
        NotificationService $notificationService
    ) {
        $this->appointmentService = $appointmentService;
        $this->notificationService = $notificationService;
    }

    /**
     * Display a listing of the appointments for the authenticated user.
     */
    public function index(Request $request): AnonymousResourceCollection
    {
        $user = $request->user();
        if (!$user) {
        abort(401, 'Unauthorized');
    }

        $query = Appointment::query();

        if ($user->isClient()) {
            $query->where('client_id', $user->id);
        } elseif ($user->isStaff()) {
            $staffId = $user->staffProfile->id;
            $query->where('staff_id', $staffId);
        } elseif ($user->isSalonOwner()) {
            $salonId = $user->ownedSalon->id;
            $query->where('salon_id', $salonId);
        }

        // Filter by status
        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        // Filter by date
        if ($request->has('date')) {
            $query->where('date', $request->date);
        }

        // Filter by upcoming/past
        if ($request->has('type')) {
            if ($request->type === 'upcoming') {
                $query->upcoming();
            } elseif ($request->type === 'past') {
                $query->past();
            }
        }

        $appointments = $query->with(['salon', 'staff', 'service'])
            ->orderBy('date')
            ->orderBy('time')
            ->paginate($request->per_page ?? 15);

        return AppointmentResource::collection($appointments);
    }

    /**
     * Store a newly created appointment in storage.
     */
    public function store(StoreAppointmentRequest $request): JsonResponse
    {
        $user = $request->user();
        $service = Service::findOrFail($request->service_id);
        $staff = Staff::findOrFail($request->staff_id);
        $salon = Salon::findOrFail($request->salon_id);

        // Check if the staff can perform this service
        if (!$staff->services->contains($service->id)) {
            return response()->json([
                'message' => 'The selected staff cannot perform this service',
            ], 422);
        }

        // Check if the staff is available at the requested time
        if (!$this->appointmentService->isStaffAvailable($staff, $request->date, $request->time, $service->duration)) {
            return response()->json([
                'message' => 'The selected staff is not available at the requested time',
            ], 422);
        }

        // Calculate end time
        $endTime = $this->appointmentService->calculateEndTime($request->time, $service->duration);

        $appointment = Appointment::create([
            'client_id' => $user->id,
            'client_name' => $user->name,
            'client_email' => $user->email,
            'client_phone' => $user->phone,
            'salon_id' => $salon->id,
            'staff_id' => $staff->id,
            'service_id' => $service->id,
            'date' => $request->date,
            'time' => $request->time,
            'end_time' => $endTime,
            'status' => 'pending',
            'notes' => $request->notes,
            'total_price' => $service->price,
            'payment_status' => 'pending',
        ]);

        // Send notifications
        $this->notificationService->sendNewAppointmentNotifications($appointment);

        return response()->json([
            'message' => 'Appointment created successfully',
            'appointment' => new AppointmentResource($appointment->load(['salon', 'staff', 'service'])),
        ], 201);
    }

    /**
     * Display the specified appointment.
     */
    public function show(Appointment $appointment): AppointmentResource
    {
        $this->authorize('view', $appointment);

        $appointment->load(['salon', 'staff', 'service', 'review']);

        return new AppointmentResource($appointment);
    }

    /**
     * Update the specified appointment in storage.
     */
    public function update(UpdateAppointmentRequest $request, Appointment $appointment): JsonResponse
    {
        $this->authorize('update', $appointment);

        // If changing date/time/staff/service, check availability
        if ($request->has('date') || $request->has('time') || $request->has('staff_id') || $request->has('service_id')) {
            $date = $request->date ?? $appointment->date;
            $time = $request->time ?? $appointment->time;
            $staffId = $request->staff_id ?? $appointment->staff_id;
            $serviceId = $request->service_id ?? $appointment->service_id;

            $staff = Staff::findOrFail($staffId);
            $service = Service::findOrFail($serviceId);

            // Check if the staff can perform this service
            if (!$staff->services->contains($service->id)) {
                return response()->json([
                    'message' => 'The selected staff cannot perform this service',
                ], 422);
            }

            // Check if the staff is available at the requested time (excluding this appointment)
            if (!$this->appointmentService->isStaffAvailable($staff, $date, $time, $service->duration, $appointment->id)) {
                return response()->json([
                    'message' => 'The selected staff is not available at the requested time',
                ], 422);
            }

            // Calculate end time if time or service changed
            if ($request->has('time') || $request->has('service_id')) {
                $request->merge([
                    'end_time' => $this->appointmentService->calculateEndTime($time, $service->duration),
                ]);

                // Update total price if service changed
                if ($request->has('service_id')) {
                    $request->merge([
                        'total_price' => $service->price,
                    ]);
                }
            }
        }

        $oldStatus = $appointment->status;
        $appointment->update($request->validated());

        // Send notifications if status changed
        if ($request->has('status') && $oldStatus !== $request->status) {
            $this->notificationService->sendAppointmentStatusChangeNotifications($appointment, $oldStatus);
        }

        return response()->json([
            'message' => 'Appointment updated successfully',
            'appointment' => new AppointmentResource($appointment->load(['salon', 'staff', 'service'])),
        ]);
    }

    /**
     * Remove the specified appointment from storage.
     */
    public function destroy(Appointment $appointment): JsonResponse
    {
        $this->authorize('delete', $appointment);

        $appointment->delete();

        return response()->json([
            'message' => 'Appointment deleted successfully',
        ]);
    }

    /**
     * Cancel the specified appointment.
     */
    public function cancel(Appointment $appointment): JsonResponse
    {
        $this->authorize('cancel', $appointment);

        if (!$appointment->canBeCancelled()) {
            return response()->json([
                'message' => 'This appointment cannot be cancelled',
            ], 422);
        }

        $oldStatus = $appointment->status;
        $appointment->update(['status' => 'cancelled']);

        // Send notifications
        $this->notificationService->sendAppointmentStatusChangeNotifications($appointment, $oldStatus);

        return response()->json([
            'message' => 'Appointment cancelled successfully',
            'appointment' => new AppointmentResource($appointment->load(['salon', 'staff', 'service'])),
        ]);
    }
}
