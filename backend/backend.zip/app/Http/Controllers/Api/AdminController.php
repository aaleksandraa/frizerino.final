<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\SalonResource;
use App\Http\Resources\UserResource;
use App\Models\Appointment;
use App\Models\Salon;
use App\Models\User;
use App\Services\NotificationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class AdminController extends Controller
{
    protected $notificationService;

    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
        $this->middleware('admin');
    }

    /**
     * Get dashboard statistics.
     */
    public function dashboardStats(): JsonResponse
    {
        $totalSalons = Salon::count();
        $pendingSalons = Salon::pending()->count();
        $approvedSalons = Salon::approved()->count();
        $suspendedSalons = Salon::suspended()->count();

        $totalUsers = User::count();
        $adminUsers = User::where('role', 'admin')->count();
        $salonUsers = User::where('role', 'salon')->count();
        $staffUsers = User::where('role', 'frizer')->count();
        $clientUsers = User::where('role', 'klijent')->count();

        $totalAppointments = Appointment::count();
        $pendingAppointments = Appointment::where('status', 'pending')->count();
        $confirmedAppointments = Appointment::where('status', 'confirmed')->count();
        $completedAppointments = Appointment::where('status', 'completed')->count();
        $cancelledAppointments = Appointment::where('status', 'cancelled')->count();

        // Calculate platform revenue (10% of completed appointments)
        $totalRevenue = Appointment::where('status', 'completed')->sum('total_price');
        $platformRevenue = $totalRevenue * 0.1;

        return response()->json([
            'salons' => [
                'total' => $totalSalons,
                'pending' => $pendingSalons,
                'approved' => $approvedSalons,
                'suspended' => $suspendedSalons,
            ],
            'users' => [
                'total' => $totalUsers,
                'admin' => $adminUsers,
                'salon' => $salonUsers,
                'staff' => $staffUsers,
                'client' => $clientUsers,
            ],
            'appointments' => [
                'total' => $totalAppointments,
                'pending' => $pendingAppointments,
                'confirmed' => $confirmedAppointments,
                'completed' => $completedAppointments,
                'cancelled' => $cancelledAppointments,
            ],
            'revenue' => [
                'total' => $totalRevenue,
                'platform' => $platformRevenue,
            ],
        ]);
    }

    /**
     * Get all users.
     */
    public function users(Request $request): AnonymousResourceCollection
    {
        $query = User::query();

        // Filter by role
        if ($request->has('role')) {
            $query->where('role', $request->role);
        }

        // Search by name or email
        if ($request->has('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('name', 'like', '%' . $request->search . '%')
                  ->orWhere('email', 'like', '%' . $request->search . '%');
            });
        }

        $users = $query->orderBy('created_at', 'desc')
            ->paginate($request->per_page ?? 15);

        return UserResource::collection($users);
    }

    /**
     * Get all salons.
     */
    public function salons(Request $request): AnonymousResourceCollection
    {
        $query = Salon::query();

        // Filter by status
        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        // Search by name, city, or owner
        if ($request->has('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('name', 'like', '%' . $request->search . '%')
                  ->orWhere('city', 'like', '%' . $request->search . '%')
                  ->orWhereHas('owner', function ($q) use ($request) {
                      $q->where('name', 'like', '%' . $request->search . '%')
                        ->orWhere('email', 'like', '%' . $request->search . '%');
                  });
            });
        }

        $salons = $query->with(['owner', 'images'])
            ->orderBy('created_at', 'desc')
            ->paginate($request->per_page ?? 15);

        return SalonResource::collection($salons);
    }

    /**
     * Approve a salon.
     */
    public function approveSalon(Salon $salon): JsonResponse
    {
        if ($salon->status === 'approved') {
            return response()->json([
                'message' => 'Salon is already approved',
            ], 422);
        }

        $salon->update(['status' => 'approved']);

        // Send notification to salon owner
        $this->notificationService->sendSalonStatusChangeNotification($salon, 'approved');

        return response()->json([
            'message' => 'Salon approved successfully',
            'salon' => new SalonResource($salon),
        ]);
    }

    /**
     * Suspend a salon.
     */
    public function suspendSalon(Salon $salon): JsonResponse
    {
        if ($salon->status === 'suspended') {
            return response()->json([
                'message' => 'Salon is already suspended',
            ], 422);
        }

        $salon->update(['status' => 'suspended']);

        // Send notification to salon owner
        $this->notificationService->sendSalonStatusChangeNotification($salon, 'suspended');

        return response()->json([
            'message' => 'Salon suspended successfully',
            'salon' => new SalonResource($salon),
        ]);
    }

    /**
     * Get analytics data.
     */
    public function analytics(Request $request): JsonResponse
    {
        $period = $request->period ?? 'month'; // day, week, month, year
        $startDate = null;
        $endDate = now();

        switch ($period) {
            case 'day':
                $startDate = now()->subDay();
                break;
            case 'week':
                $startDate = now()->subWeek();
                break;
            case 'month':
                $startDate = now()->subMonth();
                break;
            case 'year':
                $startDate = now()->subYear();
                break;
            default:
                $startDate = now()->subMonth();
        }

        // Get new users by day
        $newUsers = User::whereBetween('created_at', [$startDate, $endDate])
            ->selectRaw('DATE(created_at) as date, COUNT(*) as count')
            ->groupBy('date')
            ->get();

        // Get new salons by day
        $newSalons = Salon::whereBetween('created_at', [$startDate, $endDate])
            ->selectRaw('DATE(created_at) as date, COUNT(*) as count')
            ->groupBy('date')
            ->get();

        // Get appointments by day
        $appointments = Appointment::whereBetween('created_at', [$startDate, $endDate])
            ->selectRaw('DATE(created_at) as date, COUNT(*) as count')
            ->groupBy('date')
            ->get();

        // Get revenue by day
        $revenue = Appointment::where('status', 'completed')
            ->whereBetween('created_at', [$startDate, $endDate])
            ->selectRaw('DATE(created_at) as date, SUM(total_price) as total, SUM(total_price) * 0.1 as platform')
            ->groupBy('date')
            ->get();

        // Get top cities
        $topCities = Salon::selectRaw('city, COUNT(*) as salon_count')
            ->groupBy('city')
            ->orderBy('salon_count', 'desc')
            ->limit(5)
            ->get();

        return response()->json([
            'period' => $period,
            'start_date' => $startDate->format('Y-m-d'),
            'end_date' => $endDate->format('Y-m-d'),
            'new_users' => $newUsers,
            'new_salons' => $newSalons,
            'appointments' => $appointments,
            'revenue' => $revenue,
            'top_cities' => $topCities,
        ]);
    }
}