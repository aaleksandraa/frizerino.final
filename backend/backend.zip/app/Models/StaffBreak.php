<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StaffBreak extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'staff_id',
        'title',
        'type',
        'start_time',
        'end_time',
        'date',
        'start_date',
        'end_date',
        'is_active',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'days' => 'json',
        'date' => 'date:d.m.Y',
        'start_date' => 'date:d.m.Y',
        'end_date' => 'date:d.m.Y',
        'is_active' => 'boolean',
    ];

    /**
     * Get the staff member that owns the break.
     */
    public function staff(): BelongsTo
    {
        return $this->belongsTo(Staff::class);
    }

    /**
     * Check if the break applies to a specific date.
     */
    public function appliesTo(string $date): bool
    {
        if (!$this->is_active) {
            return false;
        }

        $checkDate = strtotime($date);
        
        switch ($this->type) {
            case 'daily':
                return true;
                
            case 'weekly':
                $dayOfWeek = strtolower(date('l', $checkDate));
                return in_array($dayOfWeek, $this->days ?? []);
                
            case 'specific_date':
                return $this->date->format('d.m.Y') === date('d.m.Y', $checkDate);
                
            case 'date_range':
                $startDate = strtotime($this->start_date->format('d.m.Y'));
                $endDate = strtotime($this->end_date->format('d.m.Y'));
                return $checkDate >= $startDate && $checkDate <= $endDate;
                
            default:
                return false;
        }
    }
}