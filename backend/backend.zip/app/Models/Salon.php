<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Salon extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'description',
        'address',
        'city',
        'postal_code',
        'country',
        'phone',
        'email',
        'website',
        'rating',
        'review_count',
        'owner_id',
        'status',
        'is_verified',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'working_hours' => 'json',
        'location' => 'json',
        'target_audience' => 'json',
        'amenities' => 'json',
        'social_media' => 'json',
        'is_verified' => 'boolean',
        'rating' => 'float',
        'review_count' => 'integer',
    ];

    /**
     * Get the owner of the salon.
     */
    public function owner(): BelongsTo
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    /**
     * Get the staff members for the salon.
     */
    public function staff(): HasMany
    {
        return $this->hasMany(Staff::class);
    }

    /**
     * Get the services for the salon.
     */
    public function services(): HasMany
    {
        return $this->hasMany(Service::class);
    }

    /**
     * Get the appointments for the salon.
     */
    public function appointments(): HasMany
    {
        return $this->hasMany(Appointment::class);
    }

    /**
     * Get the reviews for the salon.
     */
    public function reviews(): HasMany
    {
        return $this->hasMany(Review::class);
    }

    /**
     * Get the salon breaks for the salon.
     */
    public function salonBreaks(): HasMany
    {
        return $this->hasMany(SalonBreak::class);
    }

    /**
     * Get the salon vacations for the salon.
     */
    public function salonVacations(): HasMany
    {
        return $this->hasMany(SalonVacation::class);
    }

    /**
     * Get the images for the salon.
     */
    public function images(): HasMany
    {
        return $this->hasMany(SalonImage::class);
    }

    /**
     * Get the users who favorited this salon.
     */
    public function favoritedBy(): HasMany
    {
        return $this->hasMany(Favorite::class);
    }

    /**
     * Scope a query to only include approved salons.
     */
    public function scopeApproved($query)
    {
        return $query->where('status', 'approved');
    }

    /**
     * Scope a query to only include pending salons.
     */
    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    /**
     * Scope a query to only include suspended salons.
     */
    public function scopeSuspended($query)
    {
        return $query->where('status', 'suspended');
    }

    /**
     * Scope a query to filter by target audience.
     */
    public function scopeForAudience($query, array $audience)
    {
        foreach ($audience as $type => $value) {
            if ($value) {
                $query->whereJsonContains('target_audience->' . $type, true);
            }
        }
        
        return $query;
    }

    /**
     * Calculate the average rating for the salon.
     */
    public function calculateRating(): void
    {
        $reviews = $this->reviews()->get();
        $count = $reviews->count();
        
        if ($count > 0) {
            $this->rating = $reviews->avg('rating');
            $this->review_count = $count;
            $this->save();
        }
    }
}