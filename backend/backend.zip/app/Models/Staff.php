<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Staff extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id',
        'salon_id',
        'name',
        'role',
        'bio',
        'avatar',
        'rating',
        'review_count',
        'is_active',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'working_hours' => 'json',
        'specialties' => 'json',
        'is_active' => 'boolean',
        'rating' => 'float',
        'review_count' => 'integer',
    ];

    /**
     * Get the user that owns the staff profile.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the salon that the staff member belongs to.
     */
    public function salon(): BelongsTo
    {
        return $this->belongsTo(Salon::class);
    }

    /**
     * Get the services that the staff member can perform.
     */
    public function services(): BelongsToMany
    {
        return $this->belongsToMany(Service::class, 'staff_services');
    }

    /**
     * Get the appointments for the staff member.
     */
    public function appointments(): HasMany
    {
        return $this->hasMany(Appointment::class);
    }

    /**
     * Get the reviews for the staff member.
     */
    public function reviews(): HasMany
    {
        return $this->hasMany(Review::class);
    }

    /**
     * Get the breaks for the staff member.
     */
    public function breaks(): HasMany
    {
        return $this->hasMany(StaffBreak::class);
    }

    /**
     * Get the vacations for the staff member.
     */
    public function vacations(): HasMany
    {
        return $this->hasMany(StaffVacation::class);
    }

    /**
     * Calculate the average rating for the staff member.
     */
    public function calculateRating(): void
    {
        $reviews = $this->reviews()->get();
        $count = $reviews->count();
        
        if ($count > 0) {
            $this->rating = $reviews->avg('rating');
            $this->review_count = $count;
            $this->save();
        }
    }

    /**
     * Check if staff member is available on a specific date and time.
     */
    public function isAvailable(string $date, string $time, int $duration = 30): bool
    {
        // Convert date to day of week
        $dayOfWeek = strtolower(date('l', strtotime($date)));
        
        // Check working hours
        $workingHours = $this->working_hours[$dayOfWeek] ?? null;
        if (!$workingHours || !$workingHours['is_working']) {
            return false;
        }
        
        // Check if time is within working hours
        $startTime = strtotime($workingHours['start']);
        $endTime = strtotime($workingHours['end']);
        $appointmentTime = strtotime($time);
        $appointmentEndTime = strtotime("+{$duration} minutes", $appointmentTime);
        
        if ($appointmentTime < $startTime || $appointmentEndTime > $endTime) {
            return false;
        }
        
        // Check for breaks
        foreach ($this->breaks as $break) {
            if (!$break->isActive) continue;
            
            if ($break->appliesTo($date)) {
                $breakStart = strtotime($break->start_time);
                $breakEnd = strtotime($break->end_time);
                
                // Check if appointment overlaps with break
                if (($appointmentTime < $breakEnd) && ($appointmentEndTime > $breakStart)) {
                    return false;
                }
            }
        }
        
        // Check for vacations
        foreach ($this->vacations as $vacation) {
            if (!$vacation->isActive) continue;
            
            $vacationStart = strtotime($vacation->start_date);
            $vacationEnd = strtotime($vacation->end_date);
            $appointmentDate = strtotime($date);
            
            if ($appointmentDate >= $vacationStart && $appointmentDate <= $vacationEnd) {
                return false;
            }
        }
        
        // Check for existing appointments
        $existingAppointments = $this->appointments()
            ->where('date', $date)
            ->whereIn('status', ['confirmed', 'in_progress'])
            ->get();
        
        foreach ($existingAppointments as $appointment) {
            $existingStart = strtotime($appointment->time);
            $existingEnd = strtotime($appointment->end_time);
            
            // Check if appointment overlaps with existing appointment
            if (($appointmentTime < $existingEnd) && ($appointmentEndTime > $existingStart)) {
                return false;
            }
        }
        
        return true;
    }
}