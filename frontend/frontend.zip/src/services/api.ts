import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api';

// Create axios instance with default config
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
  withCredentials: true, // Important for cookies/session
});

// Add request interceptor for auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('auth_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Add response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    
    // Handle 401 Unauthorized errors (token expired)
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      // Clear auth data and redirect to login
      localStorage.removeItem('auth_token');
      localStorage.removeItem('currentUser');
      window.location.href = '/';
      
      return Promise.reject(error);
    }
    
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: async (email: string, password: string, role: string) => {
    const response = await api.post('/login', { email, password, role });
    return response.data;
  },
  
  register: async (userData: any, password: string) => {
    const data = {
      ...userData,
      password,
      password_confirmation: password
    };
    const response = await api.post('/register', data);
    return response.data;
  },
  
  logout: async () => {
    const response = await api.post('/logout');
    return response.data;
  },
  
  getUser: async () => {
    const response = await api.get('/user');
    return response.data;
  },
  
  updateProfile: async (data: any) => {
    const response = await api.put('/user/profile', data);
    return response.data;
  },
  
  changePassword: async (currentPassword: string, password: string) => {
    const response = await api.put('/user/password', {
      current_password: currentPassword,
      password,
      password_confirmation: password
    });
    return response.data;
  }
};

// Salon API
export const salonAPI = {
  getSalons: async (params: any = {}) => {
    const response = await api.get('/salons', { params });
    const payload = response.data;                           // :contentReference[oaicite:0]{index=0}
    // Laravel ResourceCollection: { data: [ … ], meta: { … }, links: { … } }
    return payload.data ?? payload;
  },

  getSalon: async (id: string) => {
    const response = await api.get(`/salons/${id}`);
    return response.data;
  },
  
  createSalon: async (data: any) => {
    const response = await api.post('/salons', data);
    return response.data;
  },
  
  updateSalon: async (id: string, data: any) => {
    const response = await api.put(`/salons/${id}`, data);
    return response.data;
  },
  
  deleteSalon: async (id: string) => {
    const response = await api.delete(`/salons/${id}`);
    return response.data;
  },
  
  uploadImages: async (id: string, formData: FormData) => {
    const response = await api.post(`/salons/${id}/images`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
    return response.data;
  },
  
  deleteImage: async (salonId: string, imageId: string) => {
    const response = await api.delete(`/salons/${salonId}/images/${imageId}`);
    return response.data;
  },
  
  setPrimaryImage: async (salonId: string, imageId: string) => {
    const response = await api.put(`/salons/${salonId}/images/${imageId}/primary`);
    return response.data;
  },
  
  getAvailableSlots: async (salonId: string, staffId: string, date: string, serviceId: string) => {
    const response = await api.get(`/salons/${salonId}/available-slots`, {
      params: { staff_id: staffId, date, service_id: serviceId }
    });
    return response.data;
  },
  
  getNearestSalons: async (latitude: number, longitude: number, radius?: number) => {
    const response = await api.get('/salons/nearest', {
      params: { latitude, longitude, radius }
    });
    const payload = response.data;                           // :contentReference[oaicite:1]{index=1}
    return payload.data ?? payload;
  },
};

// Staff API
export const staffAPI = {
  getStaff: async (salonId: string) => {
    const response = await api.get(`/salons/${salonId}/staff`);
    return response.data;
  },
  
  getStaffMember: async (salonId: string, staffId: string) => {
    const response = await api.get(`/salons/${salonId}/staff/${staffId}`);
    return response.data;
  },
  
  createStaff: async (salonId: string, data: any) => {
    const response = await api.post(`/salons/${salonId}/staff`, data);
    return response.data;
  },
  
  updateStaff: async (salonId: string, staffId: string, data: any) => {
    const response = await api.put(`/salons/${salonId}/staff/${staffId}`, data);
    return response.data;
  },
  
  deleteStaff: async (salonId: string, staffId: string) => {
    const response = await api.delete(`/salons/${salonId}/staff/${staffId}`);
    return response.data;
  },
  
  uploadAvatar: async (salonId: string, staffId: string, formData: FormData) => {
    const response = await api.post(`/salons/${salonId}/staff/${staffId}/avatar`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
    return response.data;
  },
  
  getSchedule: async (salonId: string, staffId: string) => {
    const response = await api.get(`/salons/${salonId}/staff/${staffId}/schedule`);
    return response.data;
  },
  
  getAppointments: async (salonId: string, staffId: string, params = {}) => {
    const response = await api.get(`/salons/${salonId}/staff/${staffId}/appointments`, { params });
    return response.data;
  }
};

// Service API
export const serviceAPI = {
  getServices: async (salonId: string) => {
    const response = await api.get(`/salons/${salonId}/services`);
    return response.data;
  },
  
  getServicesByCategory: async (salonId: string) => {
    const response = await api.get(`/salons/${salonId}/services/by-category`);
    return response.data;
  },
  
  getService: async (salonId: string, serviceId: string) => {
    const response = await api.get(`/salons/${salonId}/services/${serviceId}`);
    return response.data;
  },
  
  createService: async (salonId: string, data: any) => {
    const response = await api.post(`/salons/${salonId}/services`, data);
    return response.data;
  },
  
  updateService: async (salonId: string, serviceId: string, data: any) => {
    const response = await api.put(`/salons/${salonId}/services/${serviceId}`, data);
    return response.data;
  },
  
  deleteService: async (salonId: string, serviceId: string) => {
    const response = await api.delete(`/salons/${salonId}/services/${serviceId}`);
    return response.data;
  }
};

// Appointment API
export const appointmentAPI = {
  getAppointments: async (params: any = {}) => {
    const response = await api.get('/appointments', { params });
    // Laravel ResourceCollections vraćaju objekat { data: [...], meta: {...}, links: {...} }
    const payload = response.data;
    // Vratimo samo niz termina:
    return payload.data ?? payload;
  },
   

   getAppointment: async (id: string) => {
    const response = await api.get(`/appointments/${id}`);
    return response.data.data ?? response.data;
  },
  
  createAppointment: async (data: any) => {
    const response = await api.post('/appointments', data);
    return response.data ?? response.data;
  },
  
  updateAppointment: async (id: string, data: any) => {
    const response = await api.put(`/appointments/${id}`, data);
    return response.data ?? response.data;
  },
  
  deleteAppointment: async (id: string) => {
    const response = await api.delete(`/appointments/${id}`);
    return response.data ?? response.data;
  },
  
  cancelAppointment: async (id: string) => {
    const response = await api.put(`/appointments/${id}/cancel`);
    return response.data ?? response.data;
  }
};

// Review API
export const reviewAPI = {
  getSalonReviews: async (salonId: string, params = {}) => {
    const response = await api.get(`/salons/${salonId}/reviews`, { params });
    return response.data;
  },
  
  getReview: async (id: string) => {
    const response = await api.get(`/reviews/${id}`);
    return response.data;
  },
  
  createReview: async (data: any) => {
    const response = await api.post('/reviews', data);
    return response.data;
  },
  
  updateReview: async (id: string, data: any) => {
    const response = await api.put(`/reviews/${id}`, data);
    return response.data;
  },
  
  deleteReview: async (id: string) => {
    const response = await api.delete(`/reviews/${id}`);
    return response.data;
  },
  
  addResponse: async (id: string, response: string) => {
    const res = await api.post(`/reviews/${id}/response`, { response });
    return res.data;
}
};

// Schedule API
export const scheduleAPI = {
  // Salon breaks
  getSalonBreaks: async (salonId: string) => {
    const response = await api.get(`/salons/${salonId}/breaks`);
    return response.data;
  },
  
  createSalonBreak: async (salonId: string, data: any) => {
    const response = await api.post(`/salons/${salonId}/breaks`, data);
    return response.data;
  },
  
  updateSalonBreak: async (salonId: string, breakId: string, data: any) => {
    const response = await api.put(`/salons/${salonId}/breaks/${breakId}`, data);
    return response.data;
  },
  
  deleteSalonBreak: async (salonId: string, breakId: string) => {
    const response = await api.delete(`/salons/${salonId}/breaks/${breakId}`);
    return response.data;
  },
  
  // Salon vacations
  getSalonVacations: async (salonId: string) => {
    const response = await api.get(`/salons/${salonId}/vacations`);
    return response.data;
  },
  
  createSalonVacation: async (salonId: string, data: any) => {
    const response = await api.post(`/salons/${salonId}/vacations`, data);
    return response.data;
  },
  
  updateSalonVacation: async (salonId: string, vacationId: string, data: any) => {
    const response = await api.put(`/salons/${salonId}/vacations/${vacationId}`, data);
    return response.data;
  },
  
  deleteSalonVacation: async (salonId: string, vacationId: string) => {
    const response = await api.delete(`/salons/${salonId}/vacations/${vacationId}`);
    return response.data;
  },
  
  // Staff breaks
  getStaffBreaks: async (staffId: string) => {
    const response = await api.get(`/staff/${staffId}/breaks`);
    return response.data;
  },
  
  createStaffBreak: async (staffId: string, data: any) => {
    const response = await api.post(`/staff/${staffId}/breaks`, data);
    return response.data;
  },
  
  updateStaffBreak: async (staffId: string, breakId: string, data: any) => {
    const response = await api.put(`/staff/${staffId}/breaks/${breakId}`, data);
    return response.data;
  },
  
  deleteStaffBreak: async (staffId: string, breakId: string) => {
    const response = await api.delete(`/staff/${staffId}/breaks/${breakId}`);
    return response.data;
  },
  
  // Staff vacations
  getStaffVacations: async (staffId: string) => {
    const response = await api.get(`/staff/${staffId}/vacations`);
    return response.data;
  },
  
  createStaffVacation: async (staffId: string, data: any) => {
    const response = await api.post(`/staff/${staffId}/vacations`, data);
    return response.data;
  },
  
  updateStaffVacation: async (staffId: string, vacationId: string, data: any) => {
    const response = await api.put(`/staff/${staffId}/vacations/${vacationId}`, data);
    return response.data;
  },
  
  deleteStaffVacation: async (staffId: string, vacationId: string) => {
    const response = await api.delete(`/staff/${staffId}/vacations/${vacationId}`);
    return response.data;
  }
};

// Favorite API
export const favoriteAPI = {
  getFavorites: async () => {
    const response = await api.get('/favorites');
    const payload = response.data;
    return payload.data ?? payload;
  },
  
  addFavorite: async (salonId: string) => {
    const response = await api.post(`/favorites/${salonId}`);
    return response.data;
  },
  
  removeFavorite: async (salonId: string) => {
    const response = await api.delete(`/favorites/${salonId}`);
    return response.data;
  },
  
  checkFavorite: async (salonId: string) => {
    const response = await api.get(`/favorites/${salonId}/check`);
    return response.data;
  }
};

// Notification API
export const notificationAPI = {
  getNotifications: async (params = {}) => {
    const response = await api.get('/notifications', { params });
    return response.data;
  },
  
  markAsRead: async (id: string) => {
    const response = await api.put(`/notifications/${id}/read`);
    return response.data;
  },
  
  markAllAsRead: async () => {
    const response = await api.put('/notifications/read-all');
    return response.data;
  },
  
  getUnreadCount: async () => {
    const response = await api.get('/notifications/unread-count');
    return response.data;
  },
  
  deleteNotification: async (id: string) => {
    const response = await api.delete(`/notifications/${id}`);
    return response.data;
  }
};

// Admin API
export const adminAPI = {
  getDashboardStats: async () => {
    const response = await api.get('/admin/dashboard');
    return response.data;
  },
  
  getUsers: async (params = {}) => {
    const response = await api.get('/admin/users', { params });
    return response.data;
  },
  
  getSalons: async (params = {}) => {
    const response = await api.get('/admin/salons', { params });
    return response.data;
  },
  
  approveSalon: async (id: string) => {
    const response = await api.put(`/admin/salons/${id}/approve`);
    return response.data;
  },
  
  suspendSalon: async (id: string) => {
    const response = await api.put(`/admin/salons/${id}/suspend`);
    return response.data;
  },
  
  getAnalytics: async (params = {}) => {
    const response = await api.get('/admin/analytics', { params });
    return response.data;
  }
};

export default api;