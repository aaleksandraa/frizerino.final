import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Calendar, 
  DollarSign, 
  Users,
  Star,
  Clock
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { appointmentAPI, reviewAPI, staffAPI, serviceAPI } from '../../services/api';

export function SalonAnalytics() {
  const { user } = useAuth();
  const [stats, setStats] = useState<any>(null);
  const [topServices, setTopServices] = useState<any[]>([]);
  const [topStaff, setTopStaff] = useState<any[]>([]);
  const [timeSlots, setTimeSlots] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnalytics();
  }, [user]);

  const loadAnalytics = async () => {
    if (!user?.salon) return;

    try {
      setLoading(true);
      
      // Load appointments for analytics
      const appointments = await appointmentAPI.getAppointments();
      const salonAppointments = appointments.filter((app: any) => app.salon_id === user.salon.id);
      
      // Load other data
      const [services, staff, reviews] = await Promise.all([
        serviceAPI.getServices(user.salon.id),
        staffAPI.getStaff(user.salon.id),
        reviewAPI.getSalonReviews(user.salon.id)
      ]);

      // Calculate stats
      const thisMonth = new Date().getMonth() + 1;
      const thisYear = new Date().getFullYear();
      
      const thisMonthAppointments = salonAppointments.filter((app: any) => {
        const [day, month, year] = app.date.split('.');
        return parseInt(month) === thisMonth && parseInt(year) === thisYear;
      });
      
      const completedAppointments = thisMonthAppointments.filter((app: any) => app.status === 'completed');
      const totalRevenue = completedAppointments.reduce((sum: number, app: any) => sum + app.total_price, 0);
      
      const newClients = new Set(thisMonthAppointments.map((app: any) => app.client_id)).size;
      
      setStats({
        totalRevenue: totalRevenue.toFixed(2),
        appointmentCount: thisMonthAppointments.length,
        newClients,
        averageRating: reviews.length > 0 ? (reviews.reduce((sum: number, r: any) => sum + r.rating, 0) / reviews.length).toFixed(1) : '0.0'
      });

      // Calculate top services
      const serviceStats = services.map((service: any) => {
        const serviceAppointments = thisMonthAppointments.filter((app: any) => app.service_id === service.id);
        const revenue = serviceAppointments.reduce((sum: number, app: any) => sum + app.total_price, 0);
        return {
          name: service.name,
          bookings: serviceAppointments.length,
          revenue: revenue.toFixed(2),
          percentage: thisMonthAppointments.length > 0 ? Math.round((serviceAppointments.length / thisMonthAppointments.length) * 100) : 0
        };
      }).sort((a, b) => b.bookings - a.bookings).slice(0, 4);
      
      setTopServices(serviceStats);

      // Calculate top staff performance
      const staffStats = staff.map((staffMember: any) => {
        const staffAppointments = thisMonthAppointments.filter((app: any) => app.staff_id === staffMember.id);
        const revenue = staffAppointments.reduce((sum: number, app: any) => sum + app.total_price, 0);
        return {
          name: staffMember.name,
          bookings: staffAppointments.length,
          revenue: revenue.toFixed(2),
          rating: staffMember.rating
        };
      }).sort((a, b) => b.bookings - a.bookings).slice(0, 3);
      
      setTopStaff(staffStats);

      // Calculate time slot analysis
      const timeSlotStats = [];
      for (let hour = 9; hour <= 18; hour++) {
        const timeSlot = `${hour.toString().padStart(2, '0')}:00-${(hour + 1).toString().padStart(2, '0')}:00`;
        const slotAppointments = thisMonthAppointments.filter((app: any) => {
          const appHour = parseInt(app.time.split(':')[0]);
          return appHour === hour;
        });
        
        timeSlotStats.push({
          time: timeSlot,
          bookings: slotAppointments.length,
          percentage: thisMonthAppointments.length > 0 ? Math.round((slotAppointments.length / thisMonthAppointments.length) * 100) : 0
        });
      }
      
      setTimeSlots(timeSlotStats);
      
    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Učitavanje...</p>
        </div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600">Greška pri učitavanju analitike</p>
      </div>
    );
  }

  const analyticsStats = [
    {
      label: 'Ukupan prihod ovaj mesec',
      value: `€${stats.totalRevenue}`,
      change: '+18%',
      changeType: 'positive' as const,
      icon: DollarSign,
      color: 'green'
    },
    {
      label: 'Broj termina',
      value: stats.appointmentCount.toString(),
      change: '+12%',
      changeType: 'positive' as const,
      icon: Calendar,
      color: 'blue'
    },
    {
      label: 'Novi klijenti',
      value: stats.newClients.toString(),
      change: '+45%',
      changeType: 'positive' as const,
      icon: Users,
      color: 'purple'
    },
    {
      label: 'Prosečna ocena',
      value: stats.averageRating,
      change: '+0.2',
      changeType: 'positive' as const,
      icon: Star,
      color: 'yellow'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Analitika salona</h1>
        <div className="flex gap-2">
          <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            <option>Ovaj mesec</option>
            <option>Prošli mesec</option>
            <option>Ova godina</option>
          </select>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
            Izvezi izveštaj
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {analyticsStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                  <div className="flex items-center mt-2">
                    <span className={`text-sm font-medium ${
                      stat.changeType === 'positive' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {stat.change}
                    </span>
                    <span className="text-sm text-gray-500 ml-2">vs prošli mesec</span>
                  </div>
                </div>
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center bg-${stat.color}-100`}>
                  <Icon className={`w-6 h-6 text-${stat.color}-600`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Services */}
        <div className="bg-white rounded-xl shadow-sm border">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Najpopularnije usluge</h3>
            <p className="text-sm text-gray-600">Po broju rezervacija ovaj mesec</p>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {topServices.map((service, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900">{service.name}</h4>
                    <p className="text-sm text-gray-600">{service.bookings} rezervacija</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">€{service.revenue}</p>
                    <div className="w-20 bg-gray-200 rounded-full h-2 mt-1">
                      <div 
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${service.percentage}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Top Staff Performance */}
        <div className="bg-white rounded-xl shadow-sm border">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Performanse zaposlenih</h3>
            <p className="text-sm text-gray-600">Ovaj mesec</p>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {topStaff.map((staffMember, index) => (
                <div key={index} className="flex items-center justify-between p-4 border border-gray-100 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center text-white font-bold">
                      {index + 1}
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">{staffMember.name}</h4>
                      <p className="text-sm text-gray-600">{staffMember.bookings} termina</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">€{staffMember.revenue}</p>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span className="text-sm">{staffMember.rating}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Time Slot Analysis */}
      <div className="bg-white rounded-xl shadow-sm border">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Analiza termina po satima</h3>
          <p className="text-sm text-gray-600">Zauzetost po satima dana</p>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {timeSlots.map((slot, index) => (
              <div key={index} className="flex items-center justify-between p-3 border border-gray-100 rounded-lg">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="font-medium text-gray-900">{slot.time}</p>
                    <p className="text-sm text-gray-600">{slot.bookings} termina</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">{slot.percentage}%</p>
                  <div className="w-16 bg-gray-200 rounded-full h-2 mt-1">
                    <div 
                      className={`h-2 rounded-full ${
                        slot.percentage >= 90 ? 'bg-red-500' :
                        slot.percentage >= 70 ? 'bg-yellow-500' : 'bg-green-500'
                      }`}
                      style={{ width: `${slot.percentage}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}