import React from 'react';
import { 
  Home, 
  Calendar, 
  Users, 
  Settings, 
  BarChart3, 
  MapPin, 
  Star,
  Clock,
  CreditCard,
  UserCog,
  Building,
  Search,
  Heart,
  Menu,
  X
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
  isOpen?: boolean;
  onToggle?: () => void;
}

export function Sidebar({ activeSection, onSectionChange, isOpen = true, onToggle }: SidebarProps) {
  const { user } = useAuth();

  const getMenuItems = () => {
    switch (user?.role) {
      case 'admin':
        return [
          { id: 'dashboard', label: 'Dashboard', icon: Home },
          { id: 'salons', label: 'Svi saloni', icon: MapPin },
          { id: 'users', label: 'Korisnici', icon: Users },
          { id: 'analytics', label: 'Analitika', icon: BarChart3 },
          { id: 'settings', label: 'Podešavanja', icon: Settings }
        ];
      
      case 'salon':
        return [
          { id: 'dashboard', label: 'Dashboard', icon: Home },
          { id: 'profile', label: 'Profil salona', icon: Building },
          { id: 'appointments', label: 'Termini', icon: Calendar },
          { id: 'staff', label: 'Zaposleni', icon: Users },
          { id: 'services', label: 'Usluge', icon: Settings },
          { id: 'schedule', label: 'Raspored', icon: Clock },
          { id: 'calendar', label: 'Kalendar', icon: Calendar },
          { id: 'analytics', label: 'Analitika', icon: BarChart3 },
          { id: 'reviews', label: 'Recenzije', icon: Star }
        ];
      
      case 'frizer':
        return [
          { id: 'dashboard', label: 'Moji termini', icon: Home },
          { id: 'calendar', label: 'Kalendar', icon: Calendar },
          { id: 'schedule', label: 'Raspored', icon: Clock },
          { id: 'analytics', label: 'Analitika', icon: BarChart3 },
          { id: 'profile', label: 'Profil', icon: UserCog }
        ];
      
      case 'klijent':
        return [
          { id: 'dashboard', label: 'Početna', icon: Home },
          { id: 'search', label: 'Pretraži salone', icon: Search },
          { id: 'appointments', label: 'Moji termini', icon: Calendar },
          { id: 'history', label: 'Istorija', icon: Clock },
          { id: 'favorites', label: 'Omiljeni saloni', icon: Heart },
          { id: 'profile', label: 'Profil', icon: UserCog }
        ];
      
      default:
        return [];
    }
  };

  const menuItems = getMenuItems();

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={onToggle}
        className="lg:hidden fixed top-4 left-4 z-50 p-3 bg-white rounded-xl shadow-lg border border-gray-200"
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={onToggle}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 z-40 w-72 bg-white border-r border-gray-200 
        transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        lg:w-64
      `}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">SalonBooking</h1>
                <p className="text-sm text-gray-500">Beauty platform</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onSectionChange(item.id);
                    if (window.innerWidth < 1024) {
                      onToggle?.();
                    }
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                    activeSection === item.id
                      ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* User Info */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold text-sm">
                  {user?.name?.charAt(0).toUpperCase()}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{user?.name}</p>
                <p className="text-xs text-gray-500 truncate">{user?.email}</p>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}