import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Calendar, 
  Star, 
  MapPin,
  Clock,
  Heart,
  TrendingUp,
  Navigation,
  Filter,
  Users
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Salon } from '../../types';
import { getCurrentDateEuropean, formatDateEuropean } from '../../utils/dateUtils';
import { LocationService } from '../../utils/locationUtils';
import { salonAPI, appointmentAPI, favoriteAPI } from '../../services/api';

interface ClientDashboardProps {
  onBookingComplete?: () => void;
}

export function ClientDashboard({ onBookingComplete }: ClientDashboardProps) {
  const navigate = useNavigate();
  const [salonsWithAvailability, setSalonsWithAvailability] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);
  const [searchFilters, setSearchFilters] = useState({
    date: '',
    time: '',
    service: '',
    location: '',
    useCurrentLocation: true
  });
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationService] = useState(() => LocationService.getInstance());
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [upcomingAppointments, setUpcomingAppointments] = useState<any[]>([]);
  const [favorites, setFavorites] = useState<any[]>([]);
  const [stats, setStats] = useState({
    totalAppointments: 0,
    totalSpent: 0,
    favoriteSalons: 0
  });

  useEffect(() => {
    loadData();
    getCurrentLocation();
  }, []);

  useEffect(() => {
    if (searchFilters.date || searchFilters.time || searchFilters.service || searchFilters.location) {
      performAdvancedSearch();
    }
  }, [searchFilters, userLocation]);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load salons with earliest availability
      const salonsData = await salonAPI.getSalons({
        order_by: 'rating',
        order_direction: 'desc',
        per_page: 6
      });
      setSalonsWithAvailability(salonsData);
      
      // Load upcoming appointments
      const appointmentsData = await appointmentAPI.getAppointments({
        type: 'upcoming',
        per_page: 3
      });
      setUpcomingAppointments(appointmentsData);
      
      // Load favorites
      const favoritesData = await favoriteAPI.getFavorites();
      setFavorites(favoritesData.slice(0, 2));
      
      // Calculate stats
      const allAppointments = await appointmentAPI.getAppointments();
      const completedAppointments = allAppointments.filter(app => app.status === 'completed');
      
      setStats({
        totalAppointments: allAppointments.length,
        totalSpent: completedAppointments.reduce((sum, app) => sum + app.total_price, 0),
        favoriteSalons: favoritesData.length
      });
      
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getCurrentLocation = async () => {
    try {
      const location = await locationService.getCurrentLocation();
      if (location) {
        setUserLocation(location);
      }
    } catch (error) {
      console.error('Error getting user location:', error);
    }
  };

  const performAdvancedSearch = async () => {
    if (!searchFilters.date && !searchFilters.time && !searchFilters.service && !searchFilters.location) {
      setSearchResults([]);
      return;
    }

    try {
      const params: any = {};
      
      if (searchFilters.date) {
        params.date = searchFilters.date;
      }
      
      if (searchFilters.time) {
        params.time = searchFilters.time;
      }
      
      if (searchFilters.service) {
        params.service = searchFilters.service;
      }
      
      if (userLocation && searchFilters.useCurrentLocation) {
        params.latitude = userLocation.lat;
        params.longitude = userLocation.lng;
        params.radius = 10; // 10km radius
      } else if (searchFilters.location) {
        params.city = searchFilters.location;
      }
      
      const results = await salonAPI.getSalons(params);
      
      // Add distance information if we have user location
      if (userLocation) {
        results.forEach((salon: any) => {
          if (salon.location.lat && salon.location.lng) {
            const distance = locationService.calculateDistance(
              userLocation.lat, userLocation.lng, salon.location.lat, salon.location.lng
            );
            salon.distance = `${distance.toFixed(1)} km`;
          }
        });
      }
      
      setSearchResults(results);
    } catch (error) {
      console.error('Error performing search:', error);
      setSearchResults([]);
    }
  };

  const clearSearch = () => {
    setSearchFilters({
      date: '',
      time: '',
      service: '',
      location: '',
      useCurrentLocation: true
    });
    setSearchResults([]);
    setShowAdvancedSearch(false);
  };

  const handleSalonClick = (salon: Salon) => {
    navigate(`/salon/${salon.id}`);
  };

  const handleBookAppointment = (salon: Salon) => {
    navigate(`/salon/${salon.id}`);
  };

  const quickStats = [
    {
      label: 'Ukupno termina',
      value: stats.totalAppointments.toString(),
      subtitle: 'Ove godine',
      icon: Calendar,
      color: 'blue'
    },
    {
      label: 'Omiljeni saloni',
      value: stats.favoriteSalons.toString(),
      subtitle: 'Dodano u favorite',
      icon: Heart,
      color: 'red'
    },
    {
      label: 'Potrošeno',
      value: `${stats.totalSpent} KM`,
      subtitle: 'Ove godine',
      icon: TrendingUp,
      color: 'green'
    }
  ];

  return (
    <div className="space-y-4 sm:space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-2xl p-4 sm:p-6 md:p-8 text-white">
        <h1 className="text-xl sm:text-2xl md:text-3xl font-bold mb-2">Dobrodošli nazad!</h1>
        <p className="text-orange-100 mb-4 sm:mb-6 text-sm sm:text-base">Rezervišite svoj sljedeći termin ili istražite nove salone</p>
        
        {/* Advanced Search Form */}
        <div className="bg-white bg-opacity-10 rounded-xl p-4 mb-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Pronađi dostupne salone</h3>
            <button
              onClick={() => setShowAdvancedSearch(!showAdvancedSearch)}
              className="text-orange-100 hover:text-white transition-colors"
            >
              <Filter className="w-5 h-5" />
            </button>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label className="block text-sm font-medium text-orange-100 mb-1">Datum</label>
              <input
                type="date"
                min={new Date().toISOString().split('T')[0]}
                value={searchFilters.date ? searchFilters.date.split('.').reverse().join('-') : ''}
                onChange={(e) => {
                  const date = e.target.value ? formatDateEuropean(new Date(e.target.value)) : '';
                  setSearchFilters(prev => ({ ...prev, date }));
                }}
                className="w-full px-3 py-2 rounded-lg text-gray-900 text-sm"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-orange-100 mb-1">Vrijeme (opcionalno)</label>
              <input
                type="time"
                value={searchFilters.time}
                onChange={(e) => setSearchFilters(prev => ({ ...prev, time: e.target.value }))}
                className="w-full px-3 py-2 rounded-lg text-gray-900 text-sm"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-orange-100 mb-1">Usluga (opcionalno)</label>
              <input
                type="text"
                value={searchFilters.service}
                onChange={(e) => setSearchFilters(prev => ({ ...prev, service: e.target.value }))}
                placeholder="Šišanje, farbanje..."
                className="w-full px-3 py-2 rounded-lg text-gray-900 text-sm"
              />
            </div>
            
            <div className="flex items-end">
              <button
                onClick={clearSearch}
                className="w-full bg-white bg-opacity-20 px-4 py-2 rounded-lg hover:bg-opacity-30 transition-colors text-sm"
              >
                Očisti
              </button>
            </div>
          </div>
          
          {showAdvancedSearch && (
            <div className="mt-4 pt-4 border-t border-orange-300">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={searchFilters.useCurrentLocation}
                      onChange={(e) => setSearchFilters(prev => ({ ...prev, useCurrentLocation: e.target.checked }))}
                      className="rounded"
                    />
                    <span className="text-orange-100">Koristi moju lokaciju</span>
                  </label>
                </div>
                
                {!searchFilters.useCurrentLocation && (
                  <div>
                    <input
                      type="text"
                      value={searchFilters.location}
                      onChange={(e) => setSearchFilters(prev => ({ ...prev, location: e.target.value }))}
                      placeholder="Unesite grad ili adresu..."
                      className="w-full px-3 py-2 rounded-lg text-gray-900 text-sm"
                    />
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
          <button 
            onClick={() => navigate('/search')}
            className="flex items-center justify-center gap-2 bg-white bg-opacity-20 px-4 sm:px-6 py-3 rounded-lg hover:bg-opacity-30 transition-colors text-sm sm:text-base"
          >
            <Search className="w-4 h-4 sm:w-5 sm:h-5" />
            Pretražite salone
          </button>
          <button 
            onClick={() => navigate('/search')}
            className="flex items-center justify-center gap-2 bg-white text-orange-600 px-4 sm:px-6 py-3 rounded-lg hover:bg-orange-50 transition-colors text-sm sm:text-base"
          >
            <Calendar className="w-4 h-4 sm:w-5 sm:h-5" />
            Rezervišite termin
          </button>
        </div>
      </div>

      {/* Search Results */}
      {searchResults.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border">
          <div className="p-4 sm:p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Rezultati pretrage</h3>
                <p className="text-sm text-gray-600">
                  Pronađeno {searchResults.length} dostupnih salona
                  {searchFilters.date && ` za ${searchFilters.date}`}
                  {searchFilters.time && ` u ${searchFilters.time}`}
                </p>
              </div>
              <button
                onClick={clearSearch}
                className="text-gray-500 hover:text-gray-700 text-sm"
              >
                Očisti pretragu
              </button>
            </div>
          </div>
          
          <div className="p-4 sm:p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {searchResults.map((salon) => (
                <div 
                  key={salon.id} 
                  className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-all duration-200 cursor-pointer"
                  onClick={() => handleSalonClick(salon)}
                >
                  <div className="aspect-video relative">
                    <img
                      src={salon.images && salon.images.length > 0 ? salon.images[0].url : 'https://images.pexels.com/photos/3065171/pexels-photo-3065171.jpeg'}
                      alt={salon.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.currentTarget.src = 'https://images.pexels.com/photos/3065171/pexels-photo-3065171.jpeg';
                      }}
                    />
                    <div className="absolute top-3 right-3 bg-white px-2 py-1 rounded-full flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span className="text-sm font-medium">{salon.rating}</span>
                    </div>
                    {salon.distance && (
                      <div className="absolute top-3 left-3 bg-green-600 text-white px-2 py-1 rounded-full text-xs font-medium">
                        {salon.distance}
                      </div>
                    )}
                  </div>
                  
                  <div className="p-4">
                    <h4 className="font-medium text-gray-900 mb-1 truncate">{salon.name}</h4>
                    <div className="flex items-center gap-2 text-gray-600 text-sm mb-2">
                      <MapPin className="w-3 h-3 flex-shrink-0" />
                      <span className="truncate">{salon.address}, {salon.city}</span>
                    </div>
                    
                    {salon.earliest_available && (
                      <div className="flex items-center gap-2 text-green-600 text-sm mb-3">
                        <div className="w-4 h-4 bg-green-100 rounded-full flex items-center justify-center">
                          <Clock className="w-2 h-2 text-green-600" />
                        </div>
                        <span className="text-xs font-medium">Dostupan {salon.earliest_available}</span>
                      </div>
                    )}
                    
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleBookAppointment(salon);
                      }}
                      className="w-full bg-orange-500 text-white py-2.5 px-4 rounded-lg hover:bg-orange-600 transition-all text-sm font-medium"
                    >
                      Rezerviši termin
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
        {quickStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border p-4 sm:p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-600 truncate">{stat.label}</p>
                  <p className="text-lg sm:text-xl md:text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                  <p className="text-xs sm:text-sm text-gray-500 mt-1 truncate">{stat.subtitle}</p>
                </div>
                <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-lg flex items-center justify-center bg-${stat.color}-100 flex-shrink-0`}>
                  <Icon className={`w-5 h-5 sm:w-6 sm:h-6 text-${stat.color}-600`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Available Salons */}
      <div className="bg-white rounded-xl shadow-sm border">
        <div className="p-4 sm:p-6 border-b border-gray-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center">
                  <Clock className="w-3 h-3 text-orange-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">Dostupni saloni</h3>
              </div>
              <p className="text-sm text-gray-600">Saloni sa najbržim dostupnim terminima po lokaciji</p>
            </div>
            <button 
              onClick={() => navigate('/search')}
              className="text-orange-600 hover:text-orange-700 text-sm font-medium"
            >
              Pogledaj sve
            </button>
          </div>
        </div>
        
        <div className="p-4 sm:p-6">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className="text-center">
                <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-gray-600">Učitavanje salona...</p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {salonsWithAvailability.map((salon) => (
                <div 
                  key={salon.id} 
                  className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-all duration-200 cursor-pointer"
                  onClick={() => handleSalonClick(salon)}
                >
                  <div className="aspect-video relative">
                    <img
                      src={salon.images && salon.images.length > 0 ? salon.images[0].url : 'https://images.pexels.com/photos/3065171/pexels-photo-3065171.jpeg'}
                      alt={salon.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.currentTarget.src = 'https://images.pexels.com/photos/3065171/pexels-photo-3065171.jpeg';
                      }}
                    />
                    <div className="absolute top-3 right-3 bg-white px-2 py-1 rounded-full flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span className="text-sm font-medium">{salon.rating}</span>
                    </div>
                  </div>
                  
                  <div className="p-4">
                    <h4 className="font-medium text-gray-900 mb-1 truncate">{salon.name}</h4>
                    <div className="flex items-center gap-2 text-gray-600 text-sm mb-2">
                      <MapPin className="w-3 h-3 flex-shrink-0" />
                      <span className="truncate">{salon.address}, {salon.city}</span>
                    </div>
                    
                    {salon.earliest_available && (
                      <div className="flex items-center gap-2 text-green-600 text-sm mb-3">
                        <div className="w-4 h-4 bg-green-100 rounded-full flex items-center justify-center">
                          <Clock className="w-2 h-2 text-green-600" />
                        </div>
                        <span className="text-xs font-medium">Dostupan {salon.earliest_available}</span>
                      </div>
                    )}
                    
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleBookAppointment(salon);
                      }}
                      className="w-full bg-orange-500 text-white py-2.5 px-4 rounded-lg hover:bg-orange-600 transition-all text-sm font-medium"
                    >
                      Rezerviši termin
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
        {/* Upcoming Appointments */}
        <div className="bg-white rounded-xl shadow-sm border">
          <div className="p-4 sm:p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">Nadolazeći termini</h3>
              <button 
                onClick={() => navigate('/appointments')}
                className="text-orange-600 hover:text-orange-700 text-sm font-medium"
              >
                Pogledaj sve
              </button>
            </div>
          </div>
          <div className="p-4 sm:p-6">
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="w-6 h-6 border-2 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : (
              upcomingAppointments.length > 0 ? (
                <div className="space-y-4">
                  {upcomingAppointments.map((appointment, index) => (
                    <div key={index} className="p-4 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-gray-900 truncate pr-2">{appointment.salon.name}</h4>
                        <span className="text-sm text-gray-500 flex-shrink-0">{appointment.date}</span>
                      </div>
                      <p className="text-sm text-gray-600 mb-1">{appointment.service.name}</p>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>{appointment.time}</span>
                        </div>
                        <span className="truncate">sa {appointment.staff.name}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">Nema nadolazećih termina</p>
                  <button 
                    onClick={() => navigate('/search')}
                    className="mt-3 text-orange-600 hover:text-orange-700 font-medium"
                  >
                    Rezervišite termin
                  </button>
                </div>
              )
            )}
          </div>
        </div>

        {/* Favorite Salons */}
        <div className="bg-white rounded-xl shadow-sm border">
          <div className="p-4 sm:p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">Omiljeni saloni</h3>
              <button 
                onClick={() => navigate('/favorites')}
                className="text-orange-600 hover:text-orange-700 text-sm font-medium"
              >
                Pogledaj sve
              </button>
            </div>
          </div>
          <div className="p-4 sm:p-6">
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="w-6 h-6 border-2 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : (
              favorites.length > 0 ? (
                <div className="space-y-4">
                  {favorites.map((salon, index) => (
                    <div 
                      key={index} 
                      className="flex items-center gap-4 p-3 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                      onClick={() => {
                        navigate(`/salon/${salon.id}`);
                      }}
                    >
                      <img
                        src={salon.images && salon.images.length > 0 ? salon.images[0].url : 'https://images.pexels.com/photos/3065171/pexels-photo-3065171.jpeg'}
                        alt={salon.name}
                        className="w-12 h-12 rounded-lg object-cover flex-shrink-0"
                        onError={(e) => {
                          e.currentTarget.src = 'https://images.pexels.com/photos/3065171/pexels-photo-3065171.jpeg';
                        }}
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-gray-900 truncate">{salon.name}</h4>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <MapPin className="w-3 h-3 flex-shrink-0" />
                          <span className="truncate">{salon.address}, {salon.city}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className="text-sm font-medium">{salon.rating}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Heart className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">Nema omiljenih salona</p>
                  <button 
                    onClick={() => navigate('/search')}
                    className="mt-3 text-orange-600 hover:text-orange-700 font-medium"
                  >
                    Istražite salone
                  </button>
                </div>
              )
            )}
          </div>
        </div>
      </div>
    </div>
  );
}