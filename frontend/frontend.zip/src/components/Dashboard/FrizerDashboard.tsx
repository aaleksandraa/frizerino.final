import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  Clock, 
  TrendingUp, 
  DollarSign,
  User,
  Star,
  CheckCircle,
  XCircle,
  Play,
  Pause,
  Plus,
  Edit,
  Save,
  X
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { getCurrentDateEuropean, formatDateEuropean, formatTime24 } from '../../utils/dateUtils';
import { appointmentAPI, staffAPI } from '../../services/api';

export function FrizerDashboard() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState<any[]>([]);
  const [staff, setStaff] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(getCurrentDateEuropean());
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    loadData();
  }, [user]);

  const loadData = async () => {
    if (!user) return;

    try {
      setLoading(true);
      
      // Load staff profile
      if (user.staff_profile) {
        const staffData = await staffAPI.getStaffMember(user.staff_profile.salon_id, user.staff_profile.id);
        setStaff(staffData);
        
        // Load appointments for this staff member
        const appointmentsData = await staffAPI.getAppointments(user.staff_profile.salon_id, user.staff_profile.id);
        setAppointments(appointmentsData.appointments || []);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const todayAppointments = appointments.filter(app => app.date === selectedDate);
  const upcomingAppointments = appointments.filter(app => app.date >= getCurrentDateEuropean() && app.status === 'confirmed');
  
  const thisMonthAppointments = appointments.filter(app => {
    const [day, month, year] = app.date.split('.');
    const [currentDay, currentMonth, currentYear] = getCurrentDateEuropean().split('.');
    return month === currentMonth && year === currentYear && app.status !== 'cancelled';
  });

  const completedThisMonth = thisMonthAppointments.filter(app => app.status === 'completed');
  const totalRevenue = completedThisMonth.reduce((sum, app) => sum + app.total_price, 0);

  const stats = [
    {
      label: 'Danas termini',
      value: todayAppointments.length.toString(),
      subtitle: `${todayAppointments.filter(a => a.status === 'completed').length} završeno`,
      icon: Calendar,
      color: 'blue'
    },
    {
      label: 'Ovaj mjesec',
      value: thisMonthAppointments.length.toString(),
      subtitle: `${Math.round((thisMonthAppointments.length / 30) * 100)}% rast`,
      icon: TrendingUp,
      color: 'green'
    },
    {
      label: 'Prihod ove sedmice',
      value: `€${Math.round(totalRevenue)}`,
      subtitle: 'završeni termini',
      icon: DollarSign,
      color: 'purple'
    },
    {
      label: 'Moja ocjena',
      value: staff?.rating?.toFixed(1) || '0.0',
      subtitle: `${staff?.review_count || 0} recenzije`,
      icon: Star,
      color: 'yellow'
    }
  ];

  const handleAppointmentAction = async (appointmentId: string, action: 'start' | 'complete' | 'cancel') => {
    try {
      let newStatus: string;
      switch (action) {
        case 'start':
          newStatus = 'in_progress';
          break;
        case 'complete':
          newStatus = 'completed';
          break;
        case 'cancel':
          newStatus = 'cancelled';
          break;
        default:
          return;
      }

      await appointmentAPI.updateAppointment(appointmentId, { status: newStatus });
      
      // Refresh appointments
      loadData();
    } catch (error) {
      console.error('Error updating appointment:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in_progress': return 'bg-blue-100 text-blue-800';
      case 'confirmed': return 'bg-orange-100 text-orange-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return 'Završeno';
      case 'in_progress': return 'U toku';
      case 'confirmed': return 'Potvrđen';
      case 'cancelled': return 'Otkazan';
      default: return status;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Učitavanje...</p>
        </div>
      </div>
    );
  }

  if (!staff) {
    return (
      <div className="text-center py-12">
        <User className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">Profil nije pronađen</h3>
        <p className="text-gray-600">Kontaktirajte administratora salona da vam kreira profil.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Mobile Navigation */}
      <div className="lg:hidden">
        <div className="flex overflow-x-auto space-x-1 bg-gray-100 rounded-lg p-1">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Calendar },
            { id: 'calendar', label: 'Kalendar', icon: Calendar },
            { id: 'analytics', label: 'Analitika', icon: TrendingUp },
            { id: 'profile', label: 'Profil', icon: User }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium whitespace-nowrap transition-colors ${
                  activeTab === tab.id
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {activeTab === 'dashboard' && (
        <>
          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-6">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="bg-white rounded-xl shadow-sm border p-4 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-600 truncate">{stat.label}</p>
                      <p className="text-xl sm:text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                      <p className="text-sm text-gray-500 mt-1 truncate">{stat.subtitle}</p>
                    </div>
                    <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-lg flex items-center justify-center bg-${stat.color}-100 flex-shrink-0`}>
                      <Icon className={`w-5 h-5 sm:w-6 sm:h-6 text-${stat.color}-600`} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Today's Schedule */}
            <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border">
              <div className="p-4 sm:p-6 border-b border-gray-200">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Moj raspored</h3>
                    <p className="text-sm text-gray-600">
                      {new Date().toLocaleDateString('bs-BA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="date"
                      value={selectedDate.split('.').reverse().join('-')}
                      onChange={(e) => setSelectedDate(formatDateEuropean(new Date(e.target.value)))}
                      className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    />
                  </div>
                </div>
              </div>
              <div className="p-4 sm:p-6">
                <div className="space-y-4">
                  {todayAppointments.length > 0 ? (
                    todayAppointments.map((appointment) => (
                      <div key={appointment.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors gap-4">
                        <div className="flex items-center gap-4 flex-1 min-w-0">
                          <div className="text-center min-w-[60px]">
                            <div className="text-lg font-bold text-gray-900">{appointment.time}</div>
                            <div className="text-xs text-gray-500">{appointment.service?.duration || 0}min</div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-medium text-gray-900 truncate">{appointment.client_name}</h4>
                            <p className="text-sm text-gray-600 truncate">{appointment.service?.name}</p>
                            <p className="text-xs text-gray-500">€{appointment.total_price}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(appointment.status)}`}>
                            {getStatusText(appointment.status)}
                          </span>
                          
                          {appointment.status === 'confirmed' && (
                            <button
                              onClick={() => handleAppointmentAction(appointment.id, 'start')}
                              className="text-blue-600 hover:text-blue-700 p-1"
                              title="Počni termin"
                            >
                              <Play className="w-4 h-4" />
                            </button>
                          )}
                          
                          {appointment.status === 'in_progress' && (
                            <button
                              onClick={() => handleAppointmentAction(appointment.id, 'complete')}
                              className="text-green-600 hover:text-green-700 p-1"
                              title="Završi termin"
                            >
                              <CheckCircle className="w-4 h-4" />
                            </button>
                          )}
                          
                          {(appointment.status === 'confirmed' || appointment.status === 'in_progress') && (
                            <button
                              onClick={() => handleAppointmentAction(appointment.id, 'cancel')}
                              className="text-red-600 hover:text-red-700 p-1"
                              title="Otkaži termin"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8">
                      <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500">Nema termina za izabrani datum</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Profile Summary */}
            <div className="bg-white rounded-xl shadow-sm border">
              <div className="p-4 sm:p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900">Moj profil</h3>
                  <button className="text-blue-600 hover:text-blue-700 p-1">
                    <Edit className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="p-4 sm:p-6">
                <div className="text-center mb-6">
                  <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-3">
                    {staff.avatar ? (
                      <img src={staff.avatar} alt={staff.name} className="w-full h-full rounded-full object-cover" />
                    ) : (
                      <User className="w-10 h-10 text-white" />
                    )}
                  </div>
                  <h4 className="font-medium text-gray-900">{staff.name}</h4>
                  <p className="text-sm text-gray-600">{staff.role}</p>
                  <div className="flex items-center justify-center gap-1 mt-2">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="text-sm font-medium">{staff.rating}</span>
                    <span className="text-xs text-gray-500">({staff.review_count})</span>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <span className="text-sm font-medium text-gray-600">Specijalnosti:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {staff.specialties?.map((specialty: string, index: number) => (
                        <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                          {specialty}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  {staff.bio && (
                    <div>
                      <span className="text-sm font-medium text-gray-600">O meni:</span>
                      <p className="text-sm text-gray-900 mt-1">{staff.bio}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {activeTab === 'calendar' && (
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Kalendar termina</h3>
          <div className="text-center py-12 text-gray-500">
            Kalendar funkcionalnost će biti implementirana
          </div>
        </div>
      )}

      {activeTab === 'analytics' && (
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Analitika performansi</h3>
          <div className="text-center py-12 text-gray-500">
            Analitika funkcionalnost će biti implementirana
          </div>
        </div>
      )}

      {activeTab === 'profile' && (
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Moj profil</h3>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2">
              <Edit className="w-4 h-4" />
              Uredi profil
            </button>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Osnovne informacije</h4>
              <div className="space-y-2 text-sm">
                <div><strong>Ime:</strong> {staff.name}</div>
                <div><strong>Pozicija:</strong> {staff.role}</div>
                <div><strong>Ocjena:</strong> {staff.rating} ({staff.review_count} recenzija)</div>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Specijalnosti</h4>
              <div className="flex flex-wrap gap-1">
                {staff.specialties?.map((specialty: string, index: number) => (
                  <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                    {specialty}
                  </span>
                ))}
              </div>
            </div>
          </div>
          
          {staff.bio && (
            <div className="mt-6">
              <h4 className="font-medium text-gray-900 mb-2">Biografija</h4>
              <p className="text-gray-600">{staff.bio}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}