import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '../Layout/Header';
import { Sidebar } from '../Layout/Sidebar';
import { useAuth } from '../../context/AuthContext';

// Dashboard components for different user types
import { AdminDashboard } from './AdminDashboard';
import { SalonDashboard } from './SalonDashboard';
import { FrizerDashboard } from './FrizerDashboard';
import { ClientDashboard } from './ClientDashboard';

// Client components
import { SalonSearchWithMap } from '../Client/SalonSearchWithMap';
import { ClientAppointments } from '../Client/ClientAppointments';
import { ClientProfile } from '../Client/ClientProfile';
import { FavoriteSalons } from '../Client/FavoriteSalons';

// Salon components
import { SalonProfile } from '../Salon/SalonProfile';
import { SalonAppointments } from '../Salon/SalonAppointments';
import { SalonStaff } from '../Salon/SalonStaff';
import { SalonServices } from '../Salon/SalonServices';
import { SalonAnalytics } from '../Salon/SalonAnalytics';
import { SalonReviews } from '../Salon/SalonReviews';
import { SalonSchedule } from '../Salon/SalonSchedule';
import { SalonCalendar } from '../Salon/SalonCalendar';

// Admin components
import { AdminSalons } from '../Admin/AdminSalons';
import { AdminUsers } from '../Admin/AdminUsers';
import { AdminAnalytics } from '../Admin/AdminAnalytics';

// Frizer components
import { FrizerCalendar } from '../Frizer/FrizerCalendar';
import { FrizerSchedule } from '../Frizer/FrizerSchedule';

export function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Listen for section changes from header
  useEffect(() => {
    const handleSectionChange = (event: CustomEvent) => {
      setActiveSection(event.detail);
    };

    window.addEventListener('switchSection', handleSectionChange as EventListener);
    return () => window.removeEventListener('switchSection', handleSectionChange as EventListener);
  }, []);

  const handleBookingComplete = () => {
    if (user?.role === 'klijent') {
      setActiveSection('appointments');
      navigate('?booking=success');
    }
  };

  const renderContent = () => {
    switch (user?.role) {
      case 'admin':
        switch (activeSection) {
          case 'dashboard': return <AdminDashboard />;
          case 'salons': return <AdminSalons />;
          case 'users': return <AdminUsers />;
          case 'analytics': return <AdminAnalytics />;
          default: return <AdminDashboard />;
        }
      
      case 'salon':
        switch (activeSection) {
          case 'dashboard': return <SalonDashboard />;
          case 'profile': return <SalonProfile />;
          case 'appointments': return <SalonAppointments />;
          case 'staff': return <SalonStaff />;
          case 'services': return <SalonServices />;
          case 'schedule': return <SalonSchedule />;
          case 'calendar': return <SalonCalendar />;
          case 'analytics': return <SalonAnalytics />;
          case 'reviews': return <SalonReviews />;
          default: return <SalonDashboard />;
        }
      
      case 'frizer':
        switch (activeSection) {
          case 'dashboard': return <FrizerDashboard />;
          case 'calendar': return <FrizerCalendar />;
          case 'schedule': return <FrizerSchedule />;
          case 'analytics': return <SalonAnalytics />;
          case 'profile': return <ClientProfile />;
          default: return <FrizerDashboard />;
        }
      
      case 'klijent':
        switch (activeSection) {
          case 'dashboard': return <ClientDashboard onBookingComplete={handleBookingComplete} />;
          case 'search': return <SalonSearchWithMap />;
          case 'appointments': return <ClientAppointments />;
          case 'history': return <ClientAppointments />;
          case 'favorites': return <FavoriteSalons />;
          case 'profile': return <ClientProfile />;
          case 'settings': return <ClientProfile />;
          default: return <ClientDashboard onBookingComplete={handleBookingComplete} />;
        }
      
      default:
        return <div>Unauthorized</div>;
    }
  };

  const getPageTitle = () => {
    switch (user?.role) {
      case 'admin': return 'Admin Panel';
      case 'salon': return 'Salon Dashboard';
      case 'frizer': return 'Frizer Dashboard';
      case 'klijent': return 'Salon Booking';
      default: return 'Dashboard';
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar 
        activeSection={activeSection} 
        onSectionChange={setActiveSection}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />
      
      <div className="flex-1 flex flex-col lg:ml-0">
        <Header 
          title={getPageTitle()} 
          onMenuToggle={() => setSidebarOpen(!sidebarOpen)}
        />
        
        <main className="flex-1 p-4 sm:p-6 overflow-auto">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}